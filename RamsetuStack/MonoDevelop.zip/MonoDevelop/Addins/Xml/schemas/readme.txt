appconfig.xsd
-------------

Schema for app.config and web.config files.
Created by Matt Ward
GNU General Public License.

manifest.xsd
-------------

Schema for .manifest files.
Created by Matt Ward
GNU General Public License.

MonoDevelopAddIn.xsd
-------------

Schema for MonoDevelop add-in files.
Based on the SharpDevelop add-in schema created by Ivo Kovacka.
GNU General Public License.

NAnt.xsd
--------

NAnt 0.85 schema created by Hannes Kuppelwieser.
http://nant.sourceforge.net/release/0.85/nant.xsd
GNU General Public License.

XMLSchema.xsd
-------------

W3C Xml Schema.
http://www.w3.org/2001/XMLSchema.xsd
W3C Software License (http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231) - A copy of this license can be found in W3C-License.html

xslt.xsd
--------

Schema for xslt files.
Created by Matt Ward
GNU General Public License.

